LET'S TRADE ZM — UPDATED CUSTOMER FILES

Replace the existing files with the files in this package.

Files:
index.html
login.html
dashboard.html
js/app.js
js/login.js
js/dashboard.js
css/style.css
css/dashboard.css
css/signup.css

IMPORTANT:
1. Keep js/firebase.js unchanged because the Firebase configuration is now working.
2. Keep admin.html, js/admin.js and js/import-pricelist.js from the previous update.
3. The new app.js loads active products from Firestore collection:
   pricelist
4. Customer login looks up the client by phone or email and then loads
   subscriptions by clientId.
5. The dashboard expects subscriptions to contain clientId.
6. Do not delete data.js yet. It can be removed after all pages have
   been confirmed to use Firestore.
7. The signup page itself is NOT replaced by this package; signup.html
   and signup.js should be updated next so they save clients/orders/payments
   using the same Firestore schema.
